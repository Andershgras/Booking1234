using System.Security.Cryptography.X509Certificates;
using Bookingsystem.Service;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Bookingsystem.Pages.Items
{
    public class CreateItemModel : PageModel
    {
        private ItemService _itemService; //Instancefield: S� klassen kan benytte vores service og kan anvende listen af Item objekter.
        [BindProperty] //Dette angiver at der kan bindes til denne property fra html-siden
        public Models.Item Item { get; set; } //BindProperty: S�rger for at Item objektet kan bindes til vores formular.

        public CreateItemModel(ItemService itemService)
        {
            _itemService = itemService;
        }
        public IActionResult OnGet()
        {
            return Page();
        }
        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _itemService.AddItem(Item);
            return RedirectToPage("GetAllItems");
        }
    }
}

